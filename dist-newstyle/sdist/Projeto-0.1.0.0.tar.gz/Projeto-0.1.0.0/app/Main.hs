module Main (main) where

import Lib

import LyricsLibService as LLS
import System.Process

main::IO()
main = do
  apresentacaoInicial

apresentacaoInicial:: IO()
apresentacaoInicial = do
  print("Bem vindo ao Lyrics-LIB")
  threadDelay (2 * 1000000)
  _ <- system "clear"

